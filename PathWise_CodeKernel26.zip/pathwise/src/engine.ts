import type { LearningPlan } from './types';

/**
 * Transparent prototype rule engine.
 * Mastery bands: <60 revisit foundations; 60–79 consolidate; >=80 accelerate.
 */
export function getLearningPlan(mastery: number): LearningPlan {
  const safeMastery = Math.max(0, Math.min(100, Math.round(mastery)));
  if (safeMastery < 60) {
    return {
      mastery: safeMastery,
      learnMode: 'scaffolded',
      solveDifficulty: 'guided',
      testFormat: 'checkpoint',
      pace: 'revisit',
      recommendation: 'Revisit the prerequisite with a worked example, then try a guided question.'
    };
  }
  if (safeMastery < 80) {
    return {
      mastery: safeMastery,
      learnMode: 'scaffolded',
      solveDifficulty: 'guided',
      testFormat: 'checkpoint',
      pace: 'steady',
      recommendation: 'Consolidate this concept with another practice set before moving on.'
    };
  }
  return {
    mastery: safeMastery,
    learnMode: 'extension',
    solveDifficulty: 'challenge',
    testFormat: 'transfer',
    pace: 'accelerate',
    recommendation: 'You appear ready to move ahead. Try an extension task that applies the idea in a new context.'
  };
}

/** A conservative blended update prevents one answer from radically changing mastery. */
export function updateMastery(previous: number, score: number): number {
  const boundedPrevious = Math.max(0, Math.min(100, previous));
  const boundedScore = Math.max(0, Math.min(100, score));
  return Math.round((boundedPrevious * 0.65) + (boundedScore * 0.35));
}

export function getNextRecommendation(mastery: number): string {
  return getLearningPlan(mastery).recommendation;
}
