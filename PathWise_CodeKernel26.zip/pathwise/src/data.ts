import type { Learner, Topic } from './types';

export const initialLearners: Learner[] = [
  {
    id: 'ananya', name: 'Ananya', grade: 7, language: 'English',
    mastery: { fractions: 38, algebra: 72, cells: 64, motion: 0 },
    completedActivities: 8, lastActive: 'Today'
  },
  {
    id: 'aarav', name: 'Aarav', grade: 8, language: 'हिन्दी',
    mastery: { fractions: 88, algebra: 91, cells: 78, motion: 55 },
    completedActivities: 14, lastActive: 'Today'
  },
  {
    id: 'meera', name: 'Meera', grade: 6, language: 'ಕನ್ನಡ',
    mastery: { fractions: 61, algebra: 0, cells: 42, motion: 0 },
    completedActivities: 5, lastActive: 'Yesterday'
  }
];

export const topics: Topic[] = [
  {
    id: 'fractions', title: 'Fractions & equivalent values', subject: 'Mathematics', grades: 'Classes 6–7', prerequisite: 'Parts of a whole',
    concept: 'Equivalent fractions name the same quantity even when their numerators and denominators differ. Multiply or divide both parts by the same non-zero number. For example, 1/2 = 2/4 because both describe half of a whole.',
    scaffold: 'Start with a picture: divide one rectangle into 2 equal parts and shade 1. Divide an identical rectangle into 4 equal parts and shade 2. The shaded area is equal. Now connect the picture to 1/2 = 2/4.',
    extension: 'Try explaining why multiplying the numerator and denominator by the same non-zero number does not change a fraction’s value. Then find three fractions equivalent to 3/5.',
    solveQuestion: { prompt: 'Which fraction is equivalent to 1/2?', options: ['2/3', '2/4', '3/5', '1/3'], answer: 1, explanation: '2/4 simplifies to 1/2 when numerator and denominator are divided by 2.' },
    testQuestion: { prompt: 'A recipe uses 3/4 cup of water. Which option represents the same amount?', options: ['6/8 cup', '3/8 cup', '4/6 cup', '6/10 cup'], answer: 0, explanation: 'Multiply the numerator and denominator of 3/4 by 2: 6/8.' }
  },
  {
    id: 'algebra', title: 'Introduction to linear equations', subject: 'Mathematics', grades: 'Classes 7–9', prerequisite: 'Inverse operations',
    concept: 'An equation states that two expressions have the same value. To find an unknown, perform the same operation on both sides. For x + 5 = 12, subtract 5 from both sides to get x = 7.',
    scaffold: 'Think of an equation as a balanced scale. Whatever you remove from the left side, remove from the right side too. For x + 3 = 9, remove 3 from both sides: x = 6.',
    extension: 'Solve 3x + 4 = 19. Explain why each operation preserves equality, then create a real-world situation represented by your equation.',
    solveQuestion: { prompt: 'Solve: x + 6 = 14', options: ['6', '7', '8', '20'], answer: 2, explanation: 'Subtract 6 from both sides: x = 14 − 6 = 8.' },
    testQuestion: { prompt: 'A number multiplied by 3 gives 21. Which equation and solution are correct?', options: ['x + 3 = 21; x = 18', '3x = 21; x = 7', 'x − 3 = 21; x = 24', '3 + x = 21; x = 18'], answer: 1, explanation: 'The situation is 3x = 21. Divide both sides by 3 to get x = 7.' }
  },
  {
    id: 'cells', title: 'Cells: the basic unit of life', subject: 'Science', grades: 'Classes 6–8', prerequisite: 'Living and non-living things',
    concept: 'Cells are the basic structural and functional units of living organisms. Some organisms have one cell; others, including humans, have many specialised cells working together.',
    scaffold: 'Imagine a school made of classrooms. Each classroom has a role. In a similar way, cells are small units that carry out essential life functions. A group of similar cells can form a tissue.',
    extension: 'Compare a unicellular organism with a multicellular organism. Explain how specialisation changes the way cells work together.',
    solveQuestion: { prompt: 'What is the basic structural and functional unit of life?', options: ['Organ', 'Cell', 'Tissue', 'Organ system'], answer: 1, explanation: 'The cell is the basic structural and functional unit of living organisms.' },
    testQuestion: { prompt: 'Which statement best explains why multicellular organisms need specialised cells?', options: ['All cells do exactly the same task', 'Specialised cells divide without control', 'Different cells perform different functions', 'Cells do not communicate'], answer: 2, explanation: 'Specialisation allows different cells to perform particular functions efficiently.' }
  },
  {
    id: 'motion', title: 'Force and motion', subject: 'Science', grades: 'Classes 8–10', prerequisite: 'Distance and time',
    concept: 'A force is a push or pull that can change an object’s motion, direction or shape. Speed describes the distance travelled per unit of time: speed = distance ÷ time.',
    scaffold: 'Think about pushing a stationary toy car. A push can make it move. If you push harder, its motion may change more. Measure distance and time to compare how fast it moves.',
    extension: 'A cyclist covers 120 metres in 20 seconds. Calculate the average speed, then predict how long the same distance takes at half that speed.',
    solveQuestion: { prompt: 'A student walks 60 metres in 30 seconds. What is the average speed?', options: ['0.5 m/s', '2 m/s', '30 m/s', '90 m/s'], answer: 1, explanation: 'Speed = distance ÷ time = 60 ÷ 30 = 2 metres per second.' },
    testQuestion: { prompt: 'If the same distance is covered in half the time, what happens to average speed?', options: ['It halves', 'It stays the same', 'It doubles', 'It becomes zero'], answer: 2, explanation: 'For a fixed distance, halving the time doubles the average speed.' }
  }
];
