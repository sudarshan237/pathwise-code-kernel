import { describe, expect, it } from 'vitest';
import { getLearningPlan, updateMastery } from './engine';

describe('adaptive learning rules', () => {
  it('recommends a scaffolded revisit below 60%', () => {
    const plan = getLearningPlan(38);
    expect(plan.pace).toBe('revisit');
    expect(plan.learnMode).toBe('scaffolded');
  });

  it('keeps middle-band learners at a steady guided pace', () => {
    expect(getLearningPlan(72).pace).toBe('steady');
  });

  it('offers extension work at 80% mastery and above', () => {
    const plan = getLearningPlan(88);
    expect(plan.pace).toBe('accelerate');
    expect(plan.learnMode).toBe('extension');
  });

  it('bounds mastery updates and blends prior evidence with the latest score', () => {
    expect(updateMastery(40, 100)).toBe(61);
    expect(updateMastery(-20, 140)).toBe(35);
  });
});
