export type Stage = 'learn' | 'solve' | 'test';
export type Language = 'English' | 'हिन्दी' | 'ಕನ್ನಡ';

export interface Learner {
  id: string;
  name: string;
  grade: number;
  language: Language;
  mastery: Record<string, number>;
  completedActivities: number;
  lastActive: string;
}

export interface Topic {
  id: string;
  title: string;
  subject: 'Mathematics' | 'Science';
  grades: string;
  prerequisite: string;
  concept: string;
  scaffold: string;
  extension: string;
  solveQuestion: Question;
  testQuestion: Question;
}

export interface Question {
  prompt: string;
  options: string[];
  answer: number;
  explanation: string;
}

export interface LearningPlan {
  mastery: number;
  learnMode: 'scaffolded' | 'extension';
  solveDifficulty: 'guided' | 'challenge';
  testFormat: 'checkpoint' | 'transfer';
  pace: 'revisit' | 'steady' | 'accelerate';
  recommendation: string;
}

export interface AttemptRecord {
  learnerId: string;
  topicId: string;
  stage: Stage;
  correct: boolean;
  timestamp: string;
}
