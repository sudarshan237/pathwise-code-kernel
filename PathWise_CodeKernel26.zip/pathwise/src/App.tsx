import { useEffect, useMemo, useState } from 'react';
import { initialLearners, topics } from './data';
import { getLearningPlan, updateMastery } from './engine';
import type { Learner, Stage, Topic } from './types';

const STORAGE_KEY = 'pathwise-demo-v1';

type View = 'student' | 'teacher';

function readLearners(): Learner[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed: unknown = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed as Learner[];
    }
  } catch {
    // The prototype remains usable when browser storage is unavailable.
  }
  return initialLearners;
}

function App() {
  const [learners, setLearners] = useState<Learner[]>(readLearners);
  const [learnerId, setLearnerId] = useState('ananya');
  const [view, setView] = useState<View>('student');
  const [topicId, setTopicId] = useState('fractions');
  const [stage, setStage] = useState<Stage>('learn');
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [lastScore, setLastScore] = useState<number | null>(null);

  const learner = learners.find((item) => item.id === learnerId) ?? learners[0];
  const topic = topics.find((item) => item.id === topicId) ?? topics[0];
  const mastery = learner.mastery[topic.id] ?? 0;
  const plan = getLearningPlan(mastery);
  const question = stage === 'solve' ? topic.solveQuestion : topic.testQuestion;

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(learners)); } catch { /* local-only demo */ }
  }, [learners]);

  const classAverage = useMemo(() => {
    const values = learners.map((person) => person.mastery[topicId] ?? 0).filter((value) => value > 0);
    return values.length ? Math.round(values.reduce((sum, value) => sum + value, 0) / values.length) : 0;
  }, [learners, topicId]);

  function updateLearner(updated: Learner) {
    setLearners((current) => current.map((person) => person.id === updated.id ? updated : person));
  }

  function startTopic(id: string) {
    setTopicId(id);
    setStage('learn');
    setSelectedAnswer(null);
    setFeedback(null);
    setLastScore(null);
  }

  function switchLearner(id: string) {
    setLearnerId(id);
    setTopicId('fractions');
    setStage('learn');
    setSelectedAnswer(null);
    setFeedback(null);
    setLastScore(null);
  }

  function submitAnswer() {
    if (selectedAnswer === null) return;
    const correct = selectedAnswer === question.answer;
    setFeedback(`${correct ? 'Correct.' : 'Not quite.'} ${question.explanation}`);
    if (stage === 'test') {
      const score = correct ? 100 : 40;
      const nextMastery = updateMastery(mastery, score);
      setLastScore(score);
      updateLearner({
        ...learner,
        mastery: { ...learner.mastery, [topic.id]: nextMastery },
        completedActivities: learner.completedActivities + 1,
        lastActive: 'Just now'
      });
    }
  }

  function continueStage() {
    if (stage === 'learn') {
      setStage('solve');
    } else if (stage === 'solve') {
      setStage('test');
    } else {
      setStage('learn');
    }
    setSelectedAnswer(null);
    setFeedback(null);
  }

  function resetDemo() {
    setLearners(initialLearners);
    setLearnerId('ananya');
    startTopic('fractions');
  }

  const stages: Stage[] = ['learn', 'solve', 'test'];

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#home" onClick={(event) => { event.preventDefault(); setView('student'); }}>
          <span className="brand-mark">P</span>
          <span>pathwise<span className="brand-dot">.</span><small>ADAPTIVE LEARNING</small></span>
        </a>
        <nav className="main-nav" aria-label="Main navigation">
          <button className={view === 'student' ? 'nav-link active' : 'nav-link'} onClick={() => setView('student')}>Student space</button>
          <button className={view === 'teacher' ? 'nav-link active' : 'nav-link'} onClick={() => setView('teacher')}>Teacher dashboard</button>
        </nav>
        <div className="topbar-right"><span className="offline-dot" /> Demo mode <button className="avatar" aria-label="Profile">{learner.name[0]}</button></div>
      </header>

      <main className="main-content">
        {view === 'student' ? (
          <>
            <section className="welcome-row">
              <div>
                <p className="eyebrow">LEARNER SPACE · CLASS {learner.grade}</p>
                <h1>Good to see you, {learner.name} <span className="wave">✦</span></h1>
                <p className="muted">Your next step is based on what you already understand.</p>
              </div>
              <div className="learner-controls">
                <label htmlFor="learner-select">Demo learner</label>
                <select id="learner-select" value={learnerId} onChange={(event) => switchLearner(event.target.value)}>
                  {learners.map((person) => <option key={person.id} value={person.id}>{person.name} · Class {person.grade}</option>)}
                </select>
              </div>
            </section>

            <section className="student-summary">
              <div className="summary-main">
                <div className="summary-copy">
                  <span className="pill light-pill">YOUR LEARNING SNAPSHOT</span>
                  <h2>Small steps.<br /><em>Real progress.</em></h2>
                  <p>PathWise adjusts the lesson, practice and pace to your current understanding.</p>
                </div>
                <div className="summary-stat"><strong>{mastery}%</strong><span>Mastery · {topic.title}</span><div className="progress-track"><span style={{ width: `${mastery}%` }} /></div></div>
              </div>
              <div className="summary-side">
                <div><span className="side-icon">✎</span><span><strong>{learner.completedActivities}</strong><small>Activities completed</small></span></div>
                <div><span className="side-icon">◎</span><span><strong>{plan.pace === 'revisit' ? 'Build basics' : plan.pace === 'steady' ? 'Keep growing' : 'Ready to stretch'}</strong><small>Recommended pace</small></span></div>
                <div><span className="side-icon">⌂</span><span><strong>{learner.language}</strong><small>Learning language preference</small></span></div>
              </div>
            </section>

            <section className="section-heading"><div><p className="eyebrow">YOUR CURRICULUM</p><h2>Choose what to explore</h2></div><span className="section-note">Sample topics · Classes 6–10</span></section>
            <section className="topic-grid">
              {topics.filter((item) => Number(item.grades.match(/\d+/)?.[0] ?? 6) <= learner.grade + 1).map((item) => {
                const score = learner.mastery[item.id] ?? 0;
                return <button key={item.id} className={`topic-card ${topicId === item.id ? 'selected' : ''}`} onClick={() => startTopic(item.id)}>
                  <div className="topic-top"><span className={`subject-icon ${item.subject === 'Science' ? 'science' : ''}`}>{item.subject === 'Science' ? '◈' : '∑'}</span><span className="topic-score">{score ? `${score}% mastery` : 'Not started'}</span></div>
                  <span className="subject-label">{item.subject} · {item.grades}</span>
                  <strong>{item.title}</strong>
                  <span className="topic-bottom">{topicId === item.id ? 'Currently selected' : 'Open learning path'} <span>→</span></span>
                </button>;
              })}
            </section>

            <section className="workspace-section">
              <div className="workspace-title"><div><p className="eyebrow">PERSONALISED LEARNING PATH</p><h2>{topic.title}</h2></div><span className="topic-tag">{topic.subject}</span></div>
              <div className="learning-workspace">
                <div className="stage-column">
                  <div className="stage-label">YOUR SESSION</div>
                  {stages.map((item, index) => <button key={item} className={`stage-item ${stage === item ? 'current' : ''} ${stages.indexOf(stage) > index ? 'done' : ''}`} onClick={() => { if (item === 'learn' || stages.indexOf(item) <= stages.indexOf(stage)) { setStage(item); setFeedback(null); setSelectedAnswer(null); } }}>
                    <span className="stage-number">{stages.indexOf(stage) > index ? '✓' : `0${index + 1}`}</span><span><strong>{item[0].toUpperCase() + item.slice(1)}</strong><small>{item === 'learn' ? 'Understand a concept' : item === 'solve' ? 'Practise with guidance' : 'Check what you know'}</small></span>
                  </button>)}
                  <div className="adaptive-note"><span>✦</span><div><strong>Why this path?</strong><p>{plan.recommendation}</p></div></div>
                </div>

                <div className="activity-panel">
                  {stage === 'learn' ? (
                    <>
                      <div className="activity-kicker"><span className="live-dot" /> STEP 1 · LEARN {plan.learnMode === 'scaffolded' ? '· FOUNDATION MODE' : '· EXTENSION MODE'}</div>
                      <h3>{plan.learnMode === 'scaffolded' ? 'Let’s make the idea clear.' : 'Ready to think a little deeper?'}</h3>
                      <p className="activity-intro">{plan.learnMode === 'scaffolded' ? 'This explanation starts with a familiar example and builds one idea at a time.' : 'You have shown strong understanding. Connect the concept to a wider example.'}</p>
                      <div className="lesson-card"><span className="lesson-label">{plan.learnMode === 'scaffolded' ? 'GUIDED EXPLANATION' : 'EXTENSION EXPLANATION'}</span><p>{plan.learnMode === 'scaffolded' ? topic.scaffold : topic.extension}</p></div>
                      <div className="teacher-tip"><span>TEACHER IN THE LOOP</span><p>Your teacher can see this learning path and add their own explanation or classroom activity.</p></div>
                      <button className="primary-button" onClick={continueStage}>I’m ready to practise <span>→</span></button>
                    </>
                  ) : (
                    <>
                      <div className="activity-kicker"><span className="live-dot" /> STEP {stage === 'solve' ? '2' : '3'} · {stage.toUpperCase()} · {(stage === 'solve' ? plan.solveDifficulty : plan.testFormat).toUpperCase()}</div>
                      <h3>{stage === 'solve' ? 'Let’s solve one together.' : 'Quick understanding check.'}</h3>
                      <p className="activity-intro">{stage === 'solve' ? 'Choose an answer. You will see an explanation before moving forward.' : 'This check helps PathWise choose your next learning step.'}</p>
                      <div className="question-card"><span className="lesson-label">{stage === 'solve' ? 'PRACTICE QUESTION' : 'CHECKPOINT'}</span><h4>{question.prompt}</h4>
                        <div className="answer-list">{question.options.map((option, index) => <button key={option} disabled={feedback !== null} className={`answer-option ${selectedAnswer === index ? 'chosen' : ''}`} onClick={() => setSelectedAnswer(index)}><span>{String.fromCharCode(65 + index)}</span>{option}</button>)}</div>
                      </div>
                      {feedback && <div className={`feedback ${selectedAnswer === question.answer ? 'correct' : 'incorrect'}`} role="status">{feedback}</div>}
                      {lastScore !== null && stage === 'test' && <div className="result-box"><strong>{lastScore === 100 ? 'Checkpoint passed' : 'Keep practising'}</strong><span>New mastery: {learner.mastery[topic.id] ?? mastery}% · Checkpoint score: {lastScore}%</span></div>}
                      {!feedback ? <button className="primary-button" disabled={selectedAnswer === null} onClick={submitAnswer}>Check answer <span>→</span></button> : <button className="primary-button" onClick={continueStage}>{stage === 'test' ? 'Review learning path' : 'Continue to next step'} <span>→</span></button>}
                    </>
                  )}
                </div>
              </div>
            </section>
          </>
        ) : (
          <TeacherDashboard learners={learners} selectedTopic={topic} classAverage={classAverage} onSelectLearner={switchLearner} onBack={() => setView('student')} onReset={resetDemo} />
        )}
      </main>
      <footer className="footer"><span>pathwise<span className="brand-dot">.</span></span><span>Adaptive learning · Teacher-guided · Built for the Indian classroom</span><span>Prototype · Local demo data</span></footer>
    </div>
  );
}

function TeacherDashboard({ learners, selectedTopic, classAverage, onSelectLearner, onBack, onReset }: {
  learners: Learner[]; selectedTopic: Topic; classAverage: number;
  onSelectLearner: (id: string) => void; onBack: () => void; onReset: () => void;
}) {
  const sorted = [...learners].sort((a, b) => (a.mastery[selectedTopic.id] ?? 0) - (b.mastery[selectedTopic.id] ?? 0));
  const needsSupport = sorted.filter((person) => { const score = person.mastery[selectedTopic.id] ?? 0; return score > 0 && score < 60; }).length;
  const readyToAdvance = sorted.filter((person) => (person.mastery[selectedTopic.id] ?? 0) >= 80).length;

  return <>
    <section className="welcome-row teacher-welcome"><div><p className="eyebrow">TEACHER VIEW · CLASS OVERVIEW</p><h1>See the learner behind the score.</h1><p className="muted">Use learning signals to decide who needs support, practice or a new challenge.</p></div><button className="secondary-button" onClick={onBack}>← Student view</button></section>
    <section className="teacher-banner"><div><span className="pill light-pill">LIVE CLASS SNAPSHOT · DEMO DATA</span><h2>Different learners.<br /><em>Different next steps.</em></h2><p>PathWise groups students by demonstrated understanding, not by a single class-wide pace.</p></div><div className="teacher-banner-stat"><span>CLASS MASTERY · {selectedTopic.title}</span><strong>{classAverage}%</strong><div className="progress-track"><span style={{ width: `${classAverage}%` }} /></div><small>Average among learners who have started this topic</small></div></section>
    <section className="metric-grid"><div className="metric-card"><span>LEARNERS NEEDING SUPPORT</span><strong>{needsSupport}</strong><small>Below 60% mastery in this topic</small></div><div className="metric-card"><span>READY TO ADVANCE</span><strong>{readyToAdvance}</strong><small>At or above 80% mastery</small></div><div className="metric-card"><span>LEARNERS IN DEMO CLASS</span><strong>{learners.length}</strong><small>Sample profiles across Classes 6–8</small></div></section>
    <section className="teacher-table-section"><div className="section-heading"><div><p className="eyebrow">TEACHER ACTION BOARD</p><h2>Recommended next steps</h2></div><span className="section-note">Topic: {selectedTopic.title}</span></div>
      <div className="learner-table"><div className="table-head"><span>LEARNER</span><span>MASTERY</span><span>LEARNING SIGNAL</span><span>TEACHER ACTION</span></div>
        {sorted.map((person) => { const score = person.mastery[selectedTopic.id] ?? 0; const plan = getLearningPlan(score); return <div className="table-row" key={person.id}><div className="learner-cell"><span className="avatar-small">{person.name[0]}</span><span><strong>{person.name}</strong><small>Class {person.grade} · {person.language}</small></span></div><div className="mastery-cell"><strong>{score}%</strong><div className="mini-progress"><span style={{ width: `${score}%` }} /></div></div><div><span className={`signal-tag ${plan.pace}`}>{score === 0 ? 'Not started' : plan.pace === 'revisit' ? 'Needs foundations' : plan.pace === 'steady' ? 'Consolidating' : 'Ready to extend'}</span></div><div className="action-cell">{score === 0 ? 'Run a short baseline diagnostic' : plan.pace === 'revisit' ? 'Re-teach prerequisite in a small group' : plan.pace === 'steady' ? 'Assign one more guided practice set' : 'Offer an application challenge'}<button onClick={() => { onSelectLearner(person.id); onBack(); }}>Open learner →</button></div></div>; })}
      </div>
    </section>
    <section className="teacher-principle"><span>✦</span><div><strong>Teacher judgement stays central.</strong><p>These recommendations are decision support, not automated decisions. Teachers can review learner work, consider classroom context and choose the intervention.</p></div></section>
    <div className="teacher-actions"><button className="secondary-button" onClick={onReset}>Reset demo data</button><span>Progress is stored in this browser only.</span></div>
  </>;
}

export default App;
